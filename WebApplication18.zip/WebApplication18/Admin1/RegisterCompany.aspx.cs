﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;

namespace WebApplication18.Admin1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string connectionString = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
        private object lblMsg;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = @"INSERT INTO [company] (companyname, companyaddress, city, companystate, zip, Phone) 
                                    VALUES (@companyname, @companyaddress, @city, @companystate, @zip, @Phone)";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@companyname", txtCompanyName.Text.Trim());
                        cmd.Parameters.AddWithValue("@companyaddress", txtAddress.Text.Trim()); // Securely store password
                        cmd.Parameters.AddWithValue("@city", txtCity.Text.Trim());
                        cmd.Parameters.AddWithValue("@companystate", txtState.Text.Trim());
                        cmd.Parameters.AddWithValue("@zip", txtZip.Text.Trim());
                        cmd.Parameters.AddWithValue("@Phone", txtPhone.Text.Trim());
                     //  cmd.Parameters.AddWithValue("@email", txtemail.Text.Trim());

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            lblMessage.Visible = true;
                            lblMessage.Text = "Registered Successfully";
                            lblMessage.CssClass = "alert alert-success";
                            ClearFields(); // Corrected method name
                        }
                        else
                        {
                            lblMessage.Visible = true;
                            lblMessage.Text = "No rows affected. Registration might not have been successful.";
                            lblMessage.CssClass = "alert alert-warning";
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains("Violation of UNIQUE KEY constraint"))
                {
                    lblMessage.Visible = true;
                    lblMessage.Text = $"<b>{txtCompanyName.Text.Trim()}</b> company name already exists, try a new one.";
                    lblMessage.CssClass = "alert alert-danger";
                }
                else
                {
                    lblMessage.Visible = true;
                    lblMessage.Text = "An error occurred during registration. Please try again later.";
                    lblMessage.CssClass = "alert alert-danger";
                }
            }
        }

        private void ClearFields()
        {
            txtCompanyName.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtState.Text = string.Empty;
            txtZip.Text = string.Empty;
            txtPhone.Text = string.Empty;
          //  txtEmail.Text = string.Empty;
        }
    }
}