﻿//using System;
//using System.Data.SqlClient;
//using System.Configuration;
//using System.Web.UI;

//namespace WebApplication18.User
//{
//    public partial class Register : System.Web.UI.Page
//    {
//        string connectionString = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;

//        protected void Page_Load(object sender, EventArgs e)
//        {
//            // Optional: You can add initialization logic here.
//        }

//        protected void btnRegister_Click(object sender, EventArgs e)
//        {
//            try
//            {
//                using (SqlConnection con = new SqlConnection(connectionString))
//                {
//                    con.Open();
//                    string query = @"INSERT INTO [User](Username, Password, Mobile, Email, Country) 
//                                    VALUES (@Username, @Password, @Mobile, @Email, @Country)";
//                    using (SqlCommand cmd = new SqlCommand(query, con))
//                    {
//                        cmd.Parameters.AddWithValue("@Username", txtUserName.Text.Trim());
//                        cmd.Parameters.AddWithValue("@Password", HashPassword(txtConfirmPassword.Text.Trim())); // Securely store password
//                        cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim());
//                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
//                     //   cmd.Parameters.AddWithValue("@Country", ddlCountry.SelectedValue);

//                        int rowsAffected = cmd.ExecuteNonQuery();
//                        if (rowsAffected > 0)
//                        {
//                            lblMsg.Visible = true;
//                            lblMsg.Text = "Registered Successfully";
//                            lblMsg.CssClass = "alert alert-success";
//                            ClearFields(); // Corrected method name
//                        }
//                        else
//                        {
//                            lblMsg.Visible = true;
//                            lblMsg.Text = "No rows affected. Registration might not have been successful.";
//                            lblMsg.CssClass = "alert alert-warning";
//                        }
//                    }
//                }
//            }
//            catch (SqlException ex)
//            {
//                if (ex.Message.Contains("Violation of UNIQUE KEY constraint"))
//                {
//                    lblMsg.Visible = true;
//                    lblMsg.Text = $"<b>{txtUserName.Text.Trim()}</b> username already exists, try a new one.";
//                    lblMsg.CssClass = "alert alert-danger";
//                }
//                else
//                {
//                    lblMsg.Visible = true;
//                    lblMsg.Text = "An error occurred during registration. Please try again later.";
//                    lblMsg.CssClass = "alert alert-danger";
//                }
//            }
//        }

//        private string HashPassword(string password)
//        {
//            return password; 
//        }

//        private void ClearFields()
//        {
//            txtUserName.Text = string.Empty;
//            txtAddress.Text = string.Empty;
//            txtEmail.Text = string.Empty;
//            txtMobile.Text = string.Empty;
//            txtFullName.Text = string.Empty;
//            txtPassword.Text = string.Empty;
//            txtConfirmPassword.Text = string.Empty;
//            //ddlCountry.ClearSelection();
//        }

//        protected void Button1_Click(object sender, EventArgs e)
//        {

//        }

//        protected void Button1_Click1(object sender, EventArgs e)
//        {

//        }

//        protected void btnRegisterEmployer_Click(object sender, EventArgs e)
//        {
//            try
//            {
//                using (SqlConnection con = new SqlConnection(connectionString))
//                {
//                    con.Open();
//                    string query = @"INSERT INTO [User](Username, Password, Mobile, Email, Country) 
//                                    VALUES (@Username, @Password, @Mobile, @Email, @Country)";
//                    using (SqlCommand cmd = new SqlCommand(query, con))
//                    {
//                        cmd.Parameters.AddWithValue("@Username", txtUserName.Text.Trim());
//                        cmd.Parameters.AddWithValue("@Password", HashPassword(txtConfirmPassword.Text.Trim())); // Securely store password
//                        cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim());
//                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
//                       // cmd.Parameters.AddWithValue("@Country", ddlCountry.SelectedValue);

//                        int rowsAffected = cmd.ExecuteNonQuery();
//                        if (rowsAffected > 0)
//                        {
//                            lblMsg.Visible = true;
//                            lblMsg.Text = "Registered Successfully";
//                            lblMsg.CssClass = "alert alert-success";
//                            ClearFields(); // Corrected method name
//                        }
//                        else
//                        {
//                            lblMsg.Visible = true;
//                            lblMsg.Text = "No rows affected. Registration might not have been successful.";
//                            lblMsg.CssClass = "alert alert-warning";
//                        }
//                    }
//                }
//            }
//            catch (SqlException ex)
//            {
//                if (ex.Message.Contains("Violation of UNIQUE KEY constraint"))
//                {
//                    lblMsg.Visible = true;
//                    lblMsg.Text = $"<b>{txtUserName.Text.Trim()}</b> username already exists, try a new one.";
//                    lblMsg.CssClass = "alert alert-danger";
//                }
//                else
//                {
//                    lblMsg.Visible = true;
//                    lblMsg.Text = "An error occurred during registration. Please try again later.";
//                    lblMsg.CssClass = "alert alert-danger";
//                }
//            }
//        }
//    }
//}




using System;
using System.Data.SqlClient;
using System.Web.UI;

namespace WebApplication18.User
{
    public partial class Register : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Page load logic (if needed)
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                // Capture form data
                string username = txtUserName.Text.Trim();
                string password = txtPassword.Text.Trim();
                string confirmPassword = txtConfirmPassword.Text.Trim();
                string fullName = txtFullName.Text.Trim();
                string address = txtAddress.Text.Trim();
                string mobile = txtMobile.Text.Trim();
                string email = txtEmail.Text.Trim();
                string loginType = ddlLoginType.SelectedValue;

                // Validate password match
                if (password != confirmPassword)
                {
                    lblMsg.Text = "Passwords do not match.";
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                    lblMsg.Visible = true;
                    return;
                }

                // Ensure username is unique (You should add a check in the database)
                if (IsUsernameExists(username))
                {
                    lblMsg.Text = "Username already exists. Please choose another.";
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                    lblMsg.Visible = true;
                    return;
                }

                // Insert data into database
                string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["cs"].ToString();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO Users (Username, Password, FullName, Address, Mobile, Email, LoginType) " +
                                   "VALUES (@Username, @Password, @FullName, @Address, @Mobile, @Email, @LoginType)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@Password", password); // In a real app, hash the password
                        cmd.Parameters.AddWithValue("@FullName", fullName);
                        cmd.Parameters.AddWithValue("@Address", address);
                        cmd.Parameters.AddWithValue("@Mobile", mobile);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@LoginType", loginType);

                        cmd.ExecuteNonQuery();
                    }
                }

                lblMsg.Text = "Registration successful!";
                lblMsg.ForeColor = System.Drawing.Color.Green;
                lblMsg.Visible = true;

                // Redirect or clear the form (optional)
                Response.Redirect("~/User/Login.aspx");
            }
            catch (Exception ex)
            {
                lblMsg.Text = "An error occurred: " + ex.Message;
                lblMsg.ForeColor = System.Drawing.Color.Red;
                lblMsg.Visible = true;
            }
        }

        // Method to check if the username already exists
        private bool IsUsernameExists(string username)
        {
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["cs"].ToString();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Users WHERE Username = @Username";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }
    }
}

