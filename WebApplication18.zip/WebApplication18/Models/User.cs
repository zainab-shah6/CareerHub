﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication18.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public int MyProperty { get; set; }

        public Address Address { get; set; }
    }



    public class Address
    {
        public string Address1 { get; set; }
    }
}